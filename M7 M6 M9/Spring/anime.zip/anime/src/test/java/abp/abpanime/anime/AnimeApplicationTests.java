package abp.abpanime.anime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
